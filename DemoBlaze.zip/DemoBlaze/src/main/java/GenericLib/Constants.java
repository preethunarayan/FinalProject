package GenericLib;

import java.io.File;

public interface Constants {
	
	String browser="chrome";
	//step1:store file path in the file object
			 //File filepath= new File("C:\\Users\\Preethu N\\eclipse-workspace\\Sept18thBDDFramework\\TestData\\TestData.xlsx");
	File filepath= new File("C:\\Users\\Preethu N\\eclipse-workspace\\DemoBlaze\\TestData\\TestData.xlsx");
int globalWait=20;
String baseUrl="https://www.demoblaze.com";
}
